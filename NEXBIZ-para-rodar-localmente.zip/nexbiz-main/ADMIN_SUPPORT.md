# Administração e acesso excepcional de suporte

## Regras implementadas no backend
- Papel `owner` configurado exclusivamente por `NEXBIZ_OWNER_EMAILS` no servidor.
- Painel de indicadores agregados sem retornar documentos individuais de clientes ou transações.
- Listagem administrativa mínima de empresas.
- Proprietário pode solicitar acesso de suporte somente leitura, informando motivo e duração (5 a 120 minutos).
- Administrador da empresa pode aprovar ou negar a solicitação; a aprovação é limitada à empresa da sessão.
- Solicitações, aprovações, negativas e revogações geram eventos em `admin_audit`.
- Proprietário pode revogar uma concessão aprovada.

## Endpoints
- `GET /api/admin/overview`
- `GET /api/admin/companies`
- `POST /api/admin/support-requests`
- `GET /api/admin/support-requests`
- `POST /api/admin/support-requests/{id}/revoke`
- `GET /api/admin/audit`
- `GET /api/admin/company/support-requests`
- `POST /api/admin/company/support-requests/{id}/approve`
- `POST /api/admin/company/support-requests/{id}/deny`

## Ainda necessário antes de produção
1. Criar a interface do proprietário e a caixa de aprovação no painel da empresa.
2. Implementar a visualização assistida com escopo restrito e expiração efetiva, sem impersonação silenciosa.
3. Adicionar notificação por e-mail/in-app para pedidos, aprovações e início/fim de suporte.
4. Testar autorização, expiração, revogação e isolamento entre empresas com MongoDB/Supabase reais ou ambientes de teste.
5. Rever métricas agregadas para evitar inferência de dados de empresas pequenas; aplicar limiares de agregação quando necessário.
6. Configurar `NEXBIZ_OWNER_EMAILS` apenas em segredo do ambiente de hospedagem, nunca no frontend ou repositório.
