# Auditoria técnica inicial — NEXBIZ

Data da análise: 2026-11-07  
Escopo: código-fonte do arquivo ZIP fornecido. Não foi possível acessar o ambiente
de produção, as variáveis de ambiente, o projeto Supabase ou a instância MongoDB.

## Correções aplicadas nesta revisão

1. As operações `replace_one` de clientes, produtos, serviços, lançamentos
   financeiros, vendas e ordens de serviço agora incluem `company_id` no filtro.
2. As atualizações de estoque realizadas ao criar/cancelar vendas agora incluem
   `company_id` no filtro do produto.
3. `.gitignore` agora ignora `backups/` e exportações/dumps do MongoDB.
4. O backup `backups/mongo-20261107-063809.json` foi excluído do pacote revisado.
   Dumps de banco não devem ser enviados ao GitHub nem incluídos em distribuições.
5. O README foi atualizado para descrever o NEXBIZ, em vez do antigo template
   `farm-ts`.

## Verificações realizadas

- 30 arquivos Python passaram por compilação sintática (`py_compile`).
- Inspeção estática dos filtros de atualização dos routers.
- O projeto declara isolamento por `company_id` e autenticação Supabase com cookies
  `HttpOnly`.
- Não foi executada a suíte pytest nem testes de navegador: as dependências do
  backend (incluindo `motor`) e os serviços MongoDB/Supabase não estão disponíveis
  neste ambiente de análise.

## Pendências antes de produção

- Executar testes de isolamento com duas empresas e dois usuários distintos,
  incluindo tentativas de ler/alterar IDs de outra empresa.
- Adicionar proteção CSRF explícita para endpoints mutáveis autenticados por cookie
  (por exemplo, validar `Origin`/`Referer` e/ou token CSRF).
- Rever transições de estado de vendas para impedir cancelamento repetido e
  movimentações duplicadas de estoque; preferir operações atômicas/transações.
- Confirmar índices únicos e consistência dos códigos de venda/ordem de serviço
  sob requisições simultâneas.
- Revisar permissões por papel em todas as rotas e ações sensíveis.
- Validar limites, logs, backups seguros, política de retenção e restauração.
- Configurar Supabase (URL, chave anon, confirmação de e-mail, URLs de retorno,
  recuperação de senha e limites de envio) e MongoDB gerenciado.
- Executar `pytest`, typecheck (`tsc -b` conforme configuração do frontend), lint,
  build e testes Playwright em ambiente equivalente ao de hospedagem.
- Confirmar que nenhuma chave secreta, `.env`, dump real ou dado pessoal está no
  histórico do Git. `.gitignore` não remove arquivos que já estejam versionados:
  o dump antigo precisa ser removido do repositório e, se continha dados reais,
  avaliada a rotação de credenciais e a limpeza do histórico.

## Importante

Esta revisão melhora o isolamento defensivo nas operações de escrita, mas não é
uma certificação de segurança nem uma declaração de que o NEXBIZ está pronto para
produção. Não conecte empresas reais até concluir as pendências acima.
