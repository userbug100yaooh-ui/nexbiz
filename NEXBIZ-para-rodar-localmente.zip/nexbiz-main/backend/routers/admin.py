"""Painel do proprietário e fluxo auditável de suporte multiempresa.

O acesso excepcional aqui é uma concessão de suporte registrada; não há impersonação
silenciosa nem endpoint que exponha dados privados sem um fluxo de autorização separado.
"""
from datetime import datetime, timedelta, timezone
from typing import Optional
import uuid

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from lib.db import db
from lib.tenant import current_ctx
from routers.common import clean, require_role

router = APIRouter(prefix="/admin", tags=["admin"])


def _ctx():
    ctx = current_ctx.get()
    if ctx is None:
        raise HTTPException(status_code=401, detail="Faça login para continuar.")
    return ctx


def _owner():
    require_role("owner")
    return _ctx()


class SupportRequestIn(BaseModel):
    company_id: str
    reason: str = Field(min_length=10, max_length=500)
    access_level: str = "read_only"
    duration_minutes: int = Field(default=30, ge=5, le=120)


@router.get("/overview")
async def overview():
    """Indicadores agregados; não retorna registros de clientes ou transações individuais."""
    _owner()
    now = datetime.now(timezone.utc)
    month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    companies = await db.companies.count_documents({})
    users = await db.users.count_documents({})
    active_companies = await db.companies.count_documents({"status": {"$nin": ["inactive", "suspended"]}})
    sales_count = await db.sales.count_documents({})
    sales_total = await db.sales.aggregate([{"$group": {"_id": None, "total": {"$sum": "$total"}}}]).to_list(1)
    new_companies = await db.companies.count_documents({"created_at": {"$gte": month_start}})
    return {
        "companies_total": companies,
        "companies_active": active_companies,
        "users_total": users,
        "sales_count_total": sales_count,
        "sales_value_total": float(sales_total[0]["total"]) if sales_total else 0.0,
        "companies_created_this_month": new_companies,
        "generated_at": now.isoformat(),
    }


@router.get("/companies")
async def list_companies():
    """Lista administrativa mínima: identificação e estado, sem dados comerciais."""
    _owner()
    docs = await db.companies.find({}, {"_id": 0, "id": 1, "name": 1, "segment": 1, "plan": 1, "created_at": 1, "status": 1}).sort("created_at", -1).to_list(500)
    return docs


@router.post("/support-requests", status_code=201)
async def request_support_access(body: SupportRequestIn):
    owner = _owner()
    if body.access_level != "read_only":
        raise HTTPException(status_code=422, detail="A primeira versão permite somente acesso de leitura.")
    company = await db.companies.find_one({"id": body.company_id})
    if not company:
        raise HTTPException(status_code=404, detail="Empresa não encontrada.")
    now = datetime.now(timezone.utc)
    doc = {
        "id": str(uuid.uuid4()), "company_id": body.company_id,
        "company_name": company.get("name", "Empresa"), "requested_by": owner.user_id,
        "reason": body.reason, "access_level": "read_only", "duration_minutes": body.duration_minutes,
        "status": "pending", "requested_at": now, "expires_at": None,
        "approved_by": None, "approved_at": None, "revoked_at": None,
    }
    await db.support_access.insert_one(doc)
    await db.admin_audit.insert_one({"id": str(uuid.uuid4()), "actor_id": owner.user_id, "actor_role": "owner", "action": "support_access_requested", "company_id": body.company_id, "resource_id": doc["id"], "reason": body.reason, "created_at": now})
    return {k: v for k, v in doc.items() if k != "_id"}


@router.get("/support-requests")
async def list_support_requests():
    _owner()
    docs = await db.support_access.find({}).sort("requested_at", -1).to_list(200)
    return [clean(d) for d in docs]


@router.post("/support-requests/{request_id}/revoke")
async def revoke_support_access(request_id: str):
    owner = _owner()
    now = datetime.now(timezone.utc)
    result = await db.support_access.update_one({"id": request_id, "status": "approved"}, {"$set": {"status": "revoked", "revoked_at": now}})
    if not result.modified_count:
        raise HTTPException(status_code=404, detail="Acesso ativo não encontrado.")
    doc = await db.support_access.find_one({"id": request_id})
    await db.admin_audit.insert_one({"id": str(uuid.uuid4()), "actor_id": owner.user_id, "actor_role": "owner", "action": "support_access_revoked", "company_id": doc["company_id"], "resource_id": request_id, "created_at": now})
    return {"status": "revoked"}


@router.get("/audit")
async def audit_log():
    _owner()
    docs = await db.admin_audit.find({}).sort("created_at", -1).to_list(500)
    return [clean(d) for d in docs]


@router.get("/company/support-requests")
async def company_support_requests():
    ctx = _ctx()
    if ctx.role not in ("admin", "owner"):
        raise HTTPException(status_code=403, detail="Somente o administrador da empresa pode autorizar suporte.")
    docs = await db.support_access.find({"company_id": ctx.company_id}).sort("requested_at", -1).to_list(100)
    return [clean(d) for d in docs]


@router.post("/company/support-requests/{request_id}/approve")
async def approve_support_request(request_id: str):
    ctx = _ctx()
    if ctx.role != "admin":
        raise HTTPException(status_code=403, detail="Somente o administrador da empresa pode autorizar suporte.")
    now = datetime.now(timezone.utc)
    doc = await db.support_access.find_one({"id": request_id, "company_id": ctx.company_id, "status": "pending"})
    if not doc:
        raise HTTPException(status_code=404, detail="Solicitação pendente não encontrada para sua empresa.")
    expires = now + timedelta(minutes=int(doc["duration_minutes"]))
    await db.support_access.update_one({"id": request_id, "company_id": ctx.company_id, "status": "pending"}, {"$set": {"status": "approved", "approved_by": ctx.user_id, "approved_at": now, "expires_at": expires}})
    await db.admin_audit.insert_one({"id": str(uuid.uuid4()), "actor_id": ctx.user_id, "actor_role": "company_admin", "action": "support_access_approved", "company_id": ctx.company_id, "resource_id": request_id, "created_at": now})
    return {"status": "approved", "access_level": "read_only", "expires_at": expires.isoformat()}


@router.post("/company/support-requests/{request_id}/deny")
async def deny_support_request(request_id: str):
    ctx = _ctx()
    if ctx.role != "admin":
        raise HTTPException(status_code=403, detail="Somente o administrador da empresa pode negar suporte.")
    now = datetime.now(timezone.utc)
    result = await db.support_access.update_one({"id": request_id, "company_id": ctx.company_id, "status": "pending"}, {"$set": {"status": "denied", "denied_at": now}})
    if not result.modified_count:
        raise HTTPException(status_code=404, detail="Solicitação pendente não encontrada para sua empresa.")
    await db.admin_audit.insert_one({"id": str(uuid.uuid4()), "actor_id": ctx.user_id, "actor_role": "company_admin", "action": "support_access_denied", "company_id": ctx.company_id, "resource_id": request_id, "created_at": now})
    return {"status": "denied"}
