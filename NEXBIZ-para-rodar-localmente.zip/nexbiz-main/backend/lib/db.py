"""Shared Mongo handle — import `client`/`db` from here (server.py, routers, seed.py)."""

import logging
import os
from pathlib import Path

from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ASCENDING, DESCENDING, IndexModel

load_dotenv(Path(__file__).parent.parent / ".env")

mongo_url = os.environ["MONGO_URL"]
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ["DB_NAME"]]

logger = logging.getLogger(__name__)

# One entry per collection: every field a route filters, sorts, or dedupes on. Applied by ensure_indexes() at startup.
INDEXES: dict[str, list[IndexModel]] = {
    "status_checks": [IndexModel([("timestamp", DESCENDING)], name="timestamp_desc")],
    "companies": [IndexModel([("id", ASCENDING)], name="id", unique=True)],
    "users": [
        IndexModel([("id", ASCENDING)], name="id", unique=True),
        IndexModel([("email", ASCENDING)], name="email"),
        IndexModel([("company_id", ASCENDING)], name="company_id"),
        IndexModel([("supabase_user_id", ASCENDING)], name="supabase_user_id"),
    ],
    "products": [
        IndexModel([("id", ASCENDING)], name="id", unique=True),
        IndexModel([("company_id", ASCENDING), ("name", ASCENDING)], name="company_name"),
    ],
    "clients": [
        IndexModel([("id", ASCENDING)], name="id", unique=True),
        IndexModel([("company_id", ASCENDING), ("name", ASCENDING)], name="company_name"),
    ],
    "services": [
        IndexModel([("id", ASCENDING)], name="id", unique=True),
        IndexModel([("company_id", ASCENDING), ("name", ASCENDING)], name="company_name"),
    ],
    "sales": [
        IndexModel([("id", ASCENDING)], name="id", unique=True),
        IndexModel([("company_id", ASCENDING), ("code", ASCENDING)], name="company_code", unique=True),
        IndexModel([("company_id", ASCENDING), ("created_at", DESCENDING)], name="company_created"),
    ],
    "service_orders": [
        IndexModel([("id", ASCENDING)], name="id", unique=True),
        IndexModel([("company_id", ASCENDING), ("code", ASCENDING)], name="company_code", unique=True),
        IndexModel([("company_id", ASCENDING), ("created_at", DESCENDING)], name="company_created"),
    ],
    "transactions": [
        IndexModel([("id", ASCENDING)], name="id", unique=True),
        IndexModel([("company_id", ASCENDING), ("due_date", DESCENDING)], name="company_due"),
    ],
    "support_access": [
        IndexModel([("id", ASCENDING)], name="id", unique=True),
        IndexModel([("company_id", ASCENDING), ("status", ASCENDING)], name="company_status"),
        IndexModel([("requested_at", DESCENDING)], name="requested_desc"),
    ],
    "admin_audit": [IndexModel([("created_at", DESCENDING)], name="created_desc")],
}


async def ensure_indexes() -> None:
    for collection, models in INDEXES.items():
        for model in models:  # one at a time so a bad spec skips only itself
            try:
                await db[collection].create_indexes([model])
            except Exception as exc:  # never block boot on an index; the log line names what to fix
                logger.error("ensure_indexes(%s.%s): %s", collection, model.document["name"], exc)
