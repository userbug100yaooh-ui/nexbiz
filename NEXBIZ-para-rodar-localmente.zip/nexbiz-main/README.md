# NEXBIZ

Sistema web de gestão para pequenos negócios, com arquitetura multiempresa (SaaS).

## Tecnologias

- **Frontend:** React 19, TypeScript, Vite e Tailwind CSS.
- **Backend:** FastAPI, Python e Pydantic.
- **Banco de dados:** MongoDB (Motor assíncrono).
- **Autenticação:** Supabase Auth, com sessão em cookies `HttpOnly`.
- **Testes:** pytest no backend e Playwright no fluxo E2E.

## Estrutura

- `frontend/`: interface web responsiva.
- `backend/`: API, autenticação, regras de negócio e acesso ao MongoDB.
- `tests/`: testes de ponta a ponta.
- `memory/`: especificações e decisões do projeto.
- `test_reports/`: relatórios de testes anteriores.

## Execução local

Configure `backend/.env` com, no mínimo:

```env
MONGO_URL=mongodb://localhost:27017
DB_NAME=nexbiz
SUPABASE_URL=https://SEU-PROJETO.supabase.co
SUPABASE_ANON_KEY=SUA_CHAVE_ANON
APP_URL=http://localhost:3000
```

Não versione `.env` nem credenciais. Inicie o MongoDB e, em terminais separados:

```bash
cd backend
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

```bash
cd frontend
yarn install
yarn dev
```

O Vite encaminha as chamadas `/api` para o backend.

## Multiempresa e segurança

O backend resolve a empresa e o usuário a partir da sessão e aplica `company_id`
nas consultas dos dados de negócio. As rotas de leitura, criação, atualização e
exclusão devem manter esse filtro. Mudanças futuras precisam incluir testes de
isolamento entre duas empresas.

Consulte `SECURITY_AUDIT.md` antes de publicar ou importar dados reais.

## Estado do projeto

O repositório contém módulos de dashboard, clientes, produtos, serviços, vendas,
financeiro, ordens de serviço, relatórios, configurações e autenticação. A presença
de uma tela ou endpoint não significa, por si só, que o fluxo esteja validado em
produção. Execute os testes e configure os serviços externos antes de lançar.

## Administração da plataforma e suporte auditável

Configure `NEXBIZ_OWNER_EMAILS` no ambiente do backend com os e-mails dos proprietários, separados por vírgula. A atribuição do papel `owner` é feita exclusivamente pelo servidor durante o vínculo da identidade Supabase; nunca aceite esse papel do formulário público.

O backend disponibiliza endpoints `/api/admin/*` para indicadores agregados, listagem administrativa mínima, solicitações de suporte e auditoria. O suporte excepcional começa em modo somente leitura e exige aprovação do administrador da empresa, com prazo de expiração. A aprovação registra auditoria; revogações também.

**Limitação desta etapa:** o fluxo de solicitação/aprovação e os registros de auditoria estão implementados no backend, mas a interface administrativa, notificações à empresa e a sessão de visualização assistida ainda precisam ser construídas e testadas. Não conceda acesso a dados reais nem publique em produção até concluir essas etapas e os testes de integração.
