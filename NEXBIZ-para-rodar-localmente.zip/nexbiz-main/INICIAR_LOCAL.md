# Executar o NEXBIZ localmente

## Requisitos
- Computador com Docker Desktop e Docker Compose instalados.
- Conexão com a internet na primeira execução (download das imagens e pacotes).

## Passos
1. Copie `.env.example` para `.env`.
2. Abra um terminal na pasta do projeto.
3. Execute `docker compose up --build`.
4. Em outro terminal, execute `docker compose --profile setup run --rm seed` para criar os dados fictícios (o seed apaga e recria somente a empresa demonstrativa).
5. Aguarde a instalação das dependências e a mensagem de inicialização do Vite/FastAPI.
6. Abra `http://localhost:3000` no navegador. A API fica em `http://localhost:8001/docs`.
7. Na tela de login, use **Acessar demonstração** para abrir os dados fictícios.

O serviço `seed` cria registros demonstrativos na primeira execução. Para reiniciar a base de demonstração do zero: `docker compose down -v` e depois `docker compose up --build`. **Isso apaga os dados locais do volume MongoDB.**

## Limites desta execução
- O modo demonstração é somente leitura.
- Cadastro/login reais exigem configurar `SUPABASE_URL` e `SUPABASE_ANON_KEY` no `.env`.
- Este ambiente local não é publicação na internet e não deve receber dados reais.
- O painel do proprietário e o fluxo de suporte ainda precisam da interface web e dos testes de autorização ponta a ponta.

## Parar
`Ctrl+C` e depois `docker compose down`. Para preservar os dados, não use `-v`.
